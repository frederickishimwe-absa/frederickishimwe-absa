__author__ = 'Frederick'
import json
import os
from selenium.webdriver.common.by import By
from PageObjects.pages.page_locators import Locator



class CreateNewUser(object):

    """Initialising the modal elements that will be called in other classes"""
    def __init__(self, driver):
        self.driver = driver

        self.user_name = driver.find_element(By.ID, Locator.USER_NAME)
        self.username_text=""
        self.password = driver.find_element(By.ID, Locator.PASSWORD)
        self.confirm_assword = driver.find_element(By.ID, Locator.PASSWORD_CONFIRM)

        self.set_password_text=""
        self.register_button = driver.find_element(By.XPATH, Locator.REGISTER_BUTTON)
        self.userdata_path =  f"{os.getcwd()}/../test_data/user_data.json"

    """The get and setter methods to access the page elements above"""
    def get_register_button(self):
        return self.register_button

    """This method is used to simulate user entering username on login screen"""
    def enter_username(self, u):
        self.user_name.clear()
        self.user_name.send_keys( u)

    """This method is used to simulate user entering password on login screen"""
    def enter_password(self, p):
        self.password.clear()
        self.password.send_keys( p )

    def password_confirmation(self, p):
        self.confirm_assword.clear()
        self.confirm_assword.send_keys( p )

    def click_register_button(self):
        self.register_button.click()

    """This method is used to simulate user entering username and password on login screen"""
    def create_new_user(self):
        u, p = self.get_user_credentials_from_testdata()
        self.enter_username(u)
        self.enter_password(p)
        self.password_confirmation(p)
        self.click_register_button()


    """This method is used retrieve username and password credentials from  user_data file"""
    def get_user_credentials_from_testdata(self):
        try:    #Incase the file is not found, there is a fallback mechanism for credentials but this will be printed out and handled silently
            username, password = 'default','default'
            with open(self.userdata_path) as input_file:
                data = json.load(input_file)
                if data.items().__len__()>0:
                    username = data['username']
                    password = data['password']
                else:
                    raise Exception('Failed to load  and store  username = data["username"] or userdate file is empty ')
            input_file.close()          
        except Exception as error:
            print('******** Error Loading User Credentials *******\n',error)
        return username, password


