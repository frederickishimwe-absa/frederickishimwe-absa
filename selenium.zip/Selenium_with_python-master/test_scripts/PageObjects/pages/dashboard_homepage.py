__author__ = 'Frederick'
import json
import os
from selenium.webdriver.common.by import By
from PageObjects.pages.page_locators import Locator



class Dashboard_Homepage(object):

    """Initialising the modal elements that will be called in other classes"""
    def __init__(self, driver):
        self.driver = driver
        self.listenerdata_path= f"{os.getcwd()}/../test_data/listener_data.json"
        self.userdata_path =  f"{os.getcwd()}/../test_data/user_data.json"

    """This method returns the welcome message element on the top right corner for nav bar links"""
    def get_homepage_welcome_profile(self):
        return self.driver.find_element(By.XPATH, Locator.HOME_PAGE_WELCOMEPROFILE)

    def get_homepage_login_logout_element(self):
        return self.driver.find_element(By.XPATH, Locator.HOME_PAGE_LOGIN_LOGOUT)

    def get_homepage_listener_Nav_element(self):
        return self.driver.find_element(By.ID, Locator.LISTERNER)
        
    def navigate_to_listerner_page(self):
        self.get_homepage_listener_Nav_element().click()

    def get_homepage_grunt_Nav_element(self):
        self.driver.find_element(By.XPATH, Locator.GRUNT_NAV).click()
