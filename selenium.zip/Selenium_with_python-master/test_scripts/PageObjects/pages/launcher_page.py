__author__ = 'Frederick'
from asyncore import write
import json, time, pyperclip
import os
from selenium.webdriver.common.by import By
from PageObjects.pages.page_locators import Locator
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException





class Launcher_Page(object):

    """Initialising the modal elements that will be called in other classes"""
    def __init__(self, driver):
        self.driver = driver
        self.listenerdata_path= f"{os.getcwd()}/../test_data/listener_data.json"
        self.userdata_path =  f"{os.getcwd()}/../test_data/user_data.json"
        self.launcher_path =  f"{os.getcwd()}/../test_data/launcher_data.ps1"
        # covenant\covenant-ui-test\Selenium_with_python-master\test_data\launcher_data.ps1

    """This method returns the welcome message element on the top right corner for nav bar links"""
    def click_launcher_nav(self):
        self.wait_until_element( self.driver.find_element(By.ID, Locator.LAUNCHER_NAV) ).click()

        # return self.driver.find_element(By.ID, Locator.LAUNCHER_NAV).click()

    def wait_until_element(self,element):
        for i in range(1,15):
            time.sleep(2)
            try:
                if element.is_displayed():
                    return element
            except Exception as e:
                print('still waiting :',i)
        print('exhausted waiting 15s for element')
        return element

    # def click_launcher_nav(self):
    #     return self.get_homepage_launcher_Nav_element()
    

    def click_powershell_launcher(self):
        self.wait_until_element( self.driver.find_element(By.XPATH, Locator.LAUNCHER_POWERSHELL)).click()


    def select_listener(self,name):
        Select(self.driver.find_element(By.ID, Locator.LAUNCHER_LISTENER)).select_by_visible_text(name)

    def click_generate_launcher(self):
        self.driver.find_element(By.XPATH, Locator.LAUNCHER_GENERATE_BTN).click()
        # self.driver.find_element(By.XPATH, Locator.LAUNCHER_GENERATE_BTN).click()
        time.sleep(3)



    def save_launcher_to_file(self):
        self.driver.find_element(By.XPATH, Locator.LAUNCHER_SAVETOCLIPBOARD).click()
        launch_script = self.driver.find_element(By.ID, Locator.LAUNCHER_SCRIPT).get_attribute('value')
        print('\n\n -----------Launch Script--------\n',launch_script)
        with open(self.launcher_path, 'w') as lauchfile:
            lauchfile.write(launch_script)
        lauchfile.close()



