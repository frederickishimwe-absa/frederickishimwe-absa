__author__ = 'Frederick'
import json, time
import os
from selenium.webdriver.common.by import By
from PageObjects.pages.page_locators import Locator
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException





class Listener_Page(object):

    """Initialising the modal elements that will be called in other classes"""
    def __init__(self, driver):
        self.driver = driver
        self.listenerdata_path= f"{os.getcwd()}/../test_data/listener_data.json"
        self.userdata_path =  f"{os.getcwd()}/../test_data/user_data.json"

    """This method returns the welcome message element on the top right corner for nav bar links"""
    def get_homepage_listener_Nav_element(self):
        return self.driver.find_element(By.ID, Locator.LISTERNER)

    def get_create_listener_button(self):
        return self.driver.find_element(By.XPATH, Locator.LISTENER_CREATE_BTN)

    def click_create_listener(self):
        self.get_create_listener_button().click()

    def click_listener_tab(self):
        self.driver.find_element(By.ID, Locator.LISTENER_TAB).click()

    def click_bridge_listener(self):
        self.driver.find_element(By.ID, Locator.LISTENER_BRIDGE_TAB).click()

    def get_created_listener_confirmation_toast(self):
        return self.driver.find_element(By.XPATH, Locator.LISTENER_POPUP_CONFIRMATION)
    
    def get_status_listener(self):
        return self.driver.find_element(By.XPATH, Locator.LISTENER_TBL_STATUS)

    def click_listener_from_tbl(self, name):
        self.driver.find_element(By.LINK_TEXT, name).click()

    def get_stop_listener_btn(self):
        return self.driver.find_element(By.XPATH, Locator.LISTENER_STOP_BTN)

    def wait_for_element(self, locator):
        ignored_exceptions = (NoSuchElementException, StaleElementReferenceException,)
        your_element = WebDriverWait(self.driver, 40, ignored_exceptions=ignored_exceptions).until(
            ec.presence_of_element_located((By.XPATH, locator)))
        return your_element

    def wait_until_element(self,element):
        for i in range(1,15):
            time.sleep(2)
            try:
                if element.is_displayed():
                    return element
            except Exception as e:
                print('still waiting :',i)
        print('exhausted waiting 15s for element')
        return element

    def fill_listener_form(self,name="listener-0",b_address="0.0.0.0",b_port=7446,c_port=7447,c_address="192.168.68.110",b_profile="DefaultBridgeProfile"):
        print("Step 04: Enter listener Name:", name)

        #LISTENER_NAME
        self.driver.find_element(By.XPATH, Locator.LISTENER_NAME).clear()
        self.driver.find_element(By.XPATH, Locator.LISTENER_NAME).send_keys(name)
        print("Step 05: Enter listener BindAddress:", b_address)

        #LISTENER_BRIDGE_BINDADDRESS
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_BINDADDRESS).clear()
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_BINDADDRESS).send_keys(b_address)
        print("Step 06: Enter listener BindPort:", b_port)

        #LISTENER_BRIDGE_BINDPORT
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_BINDPORT).clear()
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_BINDPORT).send_keys(b_port)
        print("Step 07: Enter listener ConnectionPort:", c_port)

        #LISTENER_BRIDGE_CONNECTPORT
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_CONNECTPORT).clear()
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_CONNECTPORT).send_keys(c_port)
        print("Step 08: Enter listener ConnectionAddress:", c_address)

        #LISTENER_BRIDGE_CONNECTADDRESS
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_CONNECTADDRESS).clear()
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_CONNECTADDRESS).send_keys(c_address)
        print("Step 09: Select Dropdown Option, BridgeProfile:", b_profile)

        # LISTENER_BRIDGEPROFILE selecting DefaultBridgeProfile
        Select(self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGEPROFILE)).select_by_visible_text(b_profile)
        print("Step 10: Click on Create to create the listener")

        # click create listener
        self.driver.find_element(By.XPATH, Locator.LISTENER_BRIDGE_CREATE_BTN).click()

    def verify_listener_isActive(self, name="listener-0"):
        self.get_homepage_listener_Nav_element().click()
        self.click_listener_tab()
        print("Step 01: Wait for listener toast header status")

        element = self.wait_until_element(self.get_created_listener_confirmation_toast() )
        assert  "Started Listener" in element.text, "Failed to display listener name in the confirmation toast header"

        print("Step 02: Verify that listener status is active in the listener table")
        assert "Active" in self.get_status_listener().text,  "Failed to activate listener"
        print("Step 03: Open listener and verify that stop button is active")
        self.click_listener_from_tbl( name)
        if self.get_stop_listener_btn().is_displayed():
            assert "Stop" in self.get_stop_listener_btn().text, "Failed to display Stop Button on listener page :"
        else:
            print("Failed to display Stop Button on listener page :", self.get_stop_listener_btn().text )
        
        print("Step 04: Navigate back to main dashboard")
        self.get_homepage_listener_Nav_element().click()



