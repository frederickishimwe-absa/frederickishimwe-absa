__author__ = 'Frederick'


class Locator(object):

    """ Login Page Elements"""
    URL = 'https://127.0.0.1:7443/covenantuser/login'       #'https://127.0.0.1:7007/covenantuser/login'
    USER_NAME = "CovenantUserRegister_UserName"
    PASSWORD = "CovenantUserRegister_Password"
    PASSWORD_CONFIRM ="CovenantUserRegister_ConfirmPassword"
    REGISTER_BUTTON = "//button[@type='submit']"
    TITLE_LOGIN = 'Covenant - Login'


    """ Home Page --> Dashboard Elements"""
    HOME_PAGE_LOGIN_LOGOUT ="(//a[@class='nav-link'])[2]"
    HOME_PAGE_WELCOMEPROFILE="(//a[@class='nav-link'])[1]"

    """ Left Navigational Elements on Homepage"""
    LISTERNER="nav-listeners"

    """Listener Page Elements"""
    LISTENER_CREATE_BTN="(//a[@class='btn btn-primary'])[1]"
    LISTENER_TAB="listeners-tab"
    LISTENER_BRIDGE_TAB="bridge-tab"
    LISTENER_NAME="(//input[@id='Name'])[2]"
    LISTENER_BRIDGE_BINDADDRESS="(//input[@id='BindAddress'])[2]"
    LISTENER_BRIDGE_BINDPORT="(//input[@id='BindPort'])[2]"
    LISTENER_BRIDGE_CONNECTPORT="(//input[@id='ConnectPort'])[2]"
    LISTENER_BRIDGE_CONNECTADDRESS="(//input[@id='ConnectAddresses_0_'])[2]"
    LISTENER_BRIDGEPROFILE="(//select[@id='ProfileId'])[2]"
    LISTENER_BRIDGE_CREATE_BTN="(//button[@type='submit'])[2]"
    LISTENER_TBL="(//button[@type='submit'])[2]"
    LISTENER_POPUP_CONFIRMATION="//strong[text()='Started Listener']"
    LISTENER_TBL_STATUS="(//table[@class='table table-hover']//td)[3]"
    LISTENER_STOP_BTN="//button[text()[normalize-space()='Stop']]"


    """Launcher Page Elements"""
    LAUNCHER_NAV="nav-launchers"
    LAUNCHER_POWERSHELL="//a[text()[normalize-space()='PowerShell']]"
    LAUNCHER_LISTENER="ListenerId"
    LAUNCHER_GENERATE_BTN="//button[@type='submit']"
    LAUNCHER_SAVETOCLIPBOARD="(//span[@class='fe fe-clipboard'])[2]"
    LAUNCHER_DOWNLOAD="(//span[@class='fe fe-clipboard'])[2]"
    LAUNCHER_SCRIPT="Launcher"

    """ Grunt Page Elements"""
    GRUNT_NAV="//a[contains(.,'Grunts')]"
