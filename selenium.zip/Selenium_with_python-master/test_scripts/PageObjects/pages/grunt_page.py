__author__ = 'Frederick'
from asyncore import write
import json, time, pyperclip
import os
from selenium.webdriver.common.by import By
from PageObjects.pages.page_locators import Locator
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException





class Grunt_Page(object):

    """Initialising the modal elements that will be called in other classes"""
    def __init__(self, driver):
        self.driver = driver
        self.listenerdata_path= f"{os.getcwd()}/../test_data/listener_data.json"
        self.userdata_path =  f"{os.getcwd()}/../test_data/user_data.json"
        self.launcher_path =  f"{os.getcwd()}/../test_data/launcher_data.ps1"

    """This method returns the welcome message element on the top right corner for nav bar links"""
    def get_homepage_grunt_Nav_element(self):
        self.wait_until_element(self.driver.find_element(By.XPATH, Locator.GRUNT_NAV) ).click()
        time.sleep(2)


    def wait_until_element(self,element):
        for i in range(1,15):
            time.sleep(2)
            try:
                if element.is_displayed():
                    return element
            except Exception as e:
                print('still waiting :',i)
        print('exhausted waiting 15s for element')
        return element

