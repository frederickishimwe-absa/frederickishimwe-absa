__author__ = 'Frederick'

import os, json
import datetime


class ScreenShot():
    def __init__(self, driver):
        self.driver = driver

    '''This method ensures that screenshots are taken with timestamp '''
    def take_screen_shot(self):
        path = os.getcwd() + '/../test_evidence/' + str(datetime.datetime.now())+'.png'
        self.driver.get_screenshot_as_file(str(datetime.datetime.now())+'.png')
        self.driver.save_screenshot(str(datetime.datetime.now())+'.png')
        print('screenshot: ',path)


        

# class Test_SetupLock():
#     def __init__(self):
#         self.path = os.getcwd() + '/test_utility/lock_setup.json'
#     def set_lock(self,lock=False):
#         release = {"release": lock}
#         with open(self.path, 'w') as output_file:
#             json.dump(release, output_file)

#     def get_lock(self):
#         with open(self.path) as input_file:
#             data = json.load(input_file)
#             lock = data['release']
#         return lock
