from test_utility.screenshot import ScreenShot
from PageObjects.pages.user_login import Locator, CreateNewUser
from  unittest import TestCase
import datetime


class UserCreation():
    def __init__(self, driver):

        """Using the driver instance created in the environment setup"""
        self.driver= driver
        self.screen_shot = ScreenShot(self.driver)

    """1) Login as a User"""
    def ensure_new_user_creation(self):

        '''Navigate to URL : '''
        self.driver.get(Locator.URL)  # This is a common url, therefore this url is stored in the locator file
        self.driver.set_page_load_timeout(20)
        print('Step 01: Navigate to URL:', Locator.URL)
        self.screen_shot.take_screen_shot()
        print('---->>',self.driver.title)
        assert self.driver.title==Locator.TITLE_LOGIN ,  'Login Tile does not match or has changed'
        # TestCase.assertEqual(self.driver.title, second=Locator.TITLE_LOGIN,msg='Login Tile does not match or has changed')
        

        """Initialise Login Page elements"""
        new_user = CreateNewUser(self.driver)

        if new_user.get_login_button().is_displayed():
            new_user.create_new_user()
            print('Step 02: Create new user')
            self.driver.implicitly_wait(5)
            self.driver.save_screenshot(str(datetime.datetime.now())+'.png')
        else:
            print('Step 02: Could not create User ---> login button not visible')
            raise Exception('login Button Not Visible')

    def ensure_userLandedON_covenant_homepage_dashboard(self):
        new_user = CreateNewUser(self.driver)

        assert self.driver.page_source.contains(Locator.HOME_PAGE_DASHBOARD), " Hopme page does not dashboard or it has not loaded yet"
        assert  new_user.get_homepage_welcome_profile().is_displayed(), "Home page does not contain the welcome message on nav link header"  
        print(  new_user.get_homepage_welcome_profile().text)
        