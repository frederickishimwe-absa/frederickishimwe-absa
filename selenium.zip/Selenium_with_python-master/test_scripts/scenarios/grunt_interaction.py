from test_utility.screenshot import ScreenShot
from PageObjects.pages.grunt_page import Grunt_Page
from PageObjects.pages.dashboard_homepage import Dashboard_Homepage
import time
# from  unittest import TestCase
# import datetime


class Grunt():
    def __init__(self, driver):

        """Using the driver instance created in the environment setup"""
        self.driver= driver
        self.screen_shot = ScreenShot(self.driver)
        self.listener_name="listener-challenge-01"

    """1) This method creates a new listener based on listener data file"""
    def verify_grunt_connection_established(self):
        """Navigate to launcher page"""

        print("\nTestCase: Verify that grunt established a connection with covenant")
        launcher_page = Grunt_Page(self.driver)
        launcher_page.get_homepage_grunt_Nav_element()

