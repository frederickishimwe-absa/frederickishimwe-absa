from test_utility.screenshot import ScreenShot
from PageObjects.pages.user_login import Locator, CreateNewUser
from PageObjects.pages.dashboard_homepage import Dashboard_Homepage

# from  unittest import TestCase
import datetime, json


class UserCreation():
    def __init__(self, driver):

        """Using the driver instance created in the environment setup"""
        self.driver= driver
        self.screen_shot = ScreenShot(self.driver)

    """1) Login as a User"""
    def ensure_new_user_creation(self):

        '''Navigate to URL : '''
        self.driver.get(Locator.URL)  # This is a common url, therefore this url is stored in the locator file
        self.driver.set_page_load_timeout(20)
        print("TestCase: Ensure that new user is created successfully")

        print('Step 01: Navigate to URL:', Locator.URL)
        self.screen_shot.take_screen_shot()
        print('title:',self.driver.title)
        assert self.driver.title==Locator.TITLE_LOGIN ,  'Login Tile does not match or has changed'
        

        """Initialise Login Page elements"""
        new_user = CreateNewUser(self.driver)

        if new_user.get_register_button().is_displayed():
            new_user.create_new_user()
            print('Step 02: Create new user')
            self.driver.implicitly_wait(5)
            self.driver.save_screenshot(str(datetime.datetime.now())+'.png')
        else:
            print('Step 02: Could not create User ---> login button not visible')
            raise Exception('login Button Not Visible')
        print("TestCase: Ensure that user is logged in successfully")

    def ensure_user_landed_on_covenant_homepage_dashboard(self):
        homepage = Dashboard_Homepage(self.driver)
        print(  homepage.get_homepage_welcome_profile().text)
        with  open(homepage.userdata_path, 'r') as file1:
            loggedInUser = json.loads(file1.read()).get('username')
        file1.close()
        print(f"TestCase: Verify that home page is loaded with correct user {loggedInUser}")
        assert  homepage.get_homepage_welcome_profile().is_displayed(), "Home page does not contain the welcome message on nav link header"  
        assert homepage.get_homepage_welcome_profile().text==f"Welcome, {loggedInUser}!",  "Logged in user does not match welcome user !"
        print('Step 01: Confirm that top right corner of navlink header contains correct user in welcome message')
        assert  homepage.get_homepage_login_logout_element().is_displayed(), "Home page does not display that user can logout on nav link header"  
        assert  homepage.get_homepage_login_logout_element().text=="Logout",  "Home page does not display that user can logout text in top right corner" 
        print('Step 02: Confirm that Logout button is display in header of navlink')