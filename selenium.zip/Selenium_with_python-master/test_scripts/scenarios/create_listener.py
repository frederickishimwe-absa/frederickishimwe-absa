from test_utility.screenshot import ScreenShot
from PageObjects.pages.listener_page import Listener_Page
from PageObjects.pages.dashboard_homepage import Dashboard_Homepage

# from  unittest import TestCase
# import datetime


class CreateListener():
    def __init__(self, driver):

        """Using the driver instance created in the environment setup"""
        self.driver= driver
        self.screen_shot = ScreenShot(self.driver)
        self.listener_name="listener-challenge-01"

    """1) This method creates a new listener based on listener data file"""
    def create_listener(self):
        homepage = Dashboard_Homepage(self.driver)
        """Navigate to listener page"""
        homepage.navigate_to_listerner_page()

        print("TestCase: Create a new listener")
        listener_page = Listener_Page(self.driver)
        print("Step 01: click on create listener")
        listener_page.click_create_listener()
        print("Step 02: Navigate to bridge listener Tab")
        listener_page.click_bridge_listener()
        print("Step 03: Complete the listener form")
        listener_page.fill_listener_form(name=self.listener_name)

    def validate_listener(self):
        listener_page = Listener_Page(self.driver)

        print("TestCase: Validate Newly created listener")
        listener_page.verify_listener_isActive(self.listener_name)


        # print(  homepage.get_homepage_welcome_profile().text)
        # with  open(homepage.userdata_path, 'r') as file1:
        #     loggedInUser = json.loads(file1.read()).get('username')
        # file1.close()
        # print(f"TestCase: Verify that home page is loaded with correct user {loggedInUser}")
        # assert  homepage.get_homepage_welcome_profile().is_displayed(), "Home page does not contain the welcome message on nav link header"  
        # assert homepage.get_homepage_welcome_profile().text==f"Welcome, {loggedInUser}!",  "Logged in user does not match welcome user !"
