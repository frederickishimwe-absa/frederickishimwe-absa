from test_utility.screenshot import ScreenShot
from PageObjects.pages.launcher_page import Launcher_Page
from PageObjects.pages.dashboard_homepage import Dashboard_Homepage
import time
# from  unittest import TestCase
# import datetime


class Launcher():
    def __init__(self, driver):

        """Using the driver instance created in the environment setup"""
        self.driver= driver
        self.screen_shot = ScreenShot(self.driver)
        self.listener_name="listener-challenge-01"

    """1) This method creates a new listener based on listener data file"""
    def generate_launcher(self):
        """Navigate to launcher page"""

        print("\nTestCase: Create a new launcher")
        launcher_page = Launcher_Page(self.driver)
        launcher_page.click_launcher_nav()

        print("Step 01: click on powershell launcher")
        launcher_page.click_powershell_launcher()
        print("Step 02: select listener for launcher")
        launcher_page.select_listener(self.listener_name)
        time.sleep(5)
        print("Step 03: click on generate launcher")
        launcher_page.click_generate_launcher()
        print("Step 04: Copy generated launcher script")
        launcher_page.save_launcher_to_file()

