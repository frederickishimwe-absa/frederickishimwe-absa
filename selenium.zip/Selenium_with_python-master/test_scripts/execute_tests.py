__author__ = 'Frederick'

import unittest, datetime
from scenarios.create_user import UserCreation 
from scenarios.create_listener import  CreateListener
from scenarios.create_launcher import  Launcher
from scenarios.grunt_interaction import  Grunt




from test_utility.screenshot import ScreenShot
from test_base.environment_setup import Environment_Setup

"""test_env object will be used to maintain the state of webdriver throughout the test lifecyle and closes all the browser instances and then quits"""
test_env = Environment_Setup()


"""This is an acceptance test suite, with test cases for the covenant workflow test coverage"""
class C2_UserJourney_RedTeam(unittest.TestCase):

    """TearDown method closes all the browser instances and then quits"""
    @classmethod
    def tearDownClass(cls):
        test_env.tearDown()

    """setUpClass method runs once for all testcases"""
    @classmethod
    def setUpClass(cls):
        test_env.setup()

    """1) Login as a User"""
    def test_1_Login_as_User(self):

        """TestCases cover user creation, login and verify landing page"""
        new_user=UserCreation(test_env.driver)
        new_user.ensure_new_user_creation()
        new_user.ensure_user_landed_on_covenant_homepage_dashboard()

        
    """2)   Create a listener in the webapp ready to manage new incoming connection."""
    def test_2_CreateListener(self):
        
        """TestCases cover creating listener and ensuring that its running"""
        listener=CreateListener(test_env.driver)
        listener.create_listener()
        listener.validate_listener()


    """3)   Generate a launcher  """
    def test_3_Generate_Launcher(self):
        launcher=Launcher(test_env.driver)
        launcher.generate_launcher()


    """4)   Download the launcher file generated using the launcher form """
    def test_4_Download_Launcher(self):
        self.driver = test_env.driver
        screen_shot = ScreenShot(self.driver)
        self.driver.save_screenshot(str(datetime.datetime.now())+'.png')
        print('---->>',self.driver.title)

        pass

    """5)   Upload the launcher file on a target machine with windows installed and windows defender disabled """
    def test_5_Upload_Launcher(self):
        self.driver = test_env.driver
        screen_shot = ScreenShot(self.driver)
        self.driver.save_screenshot(str(datetime.datetime.now())+'.png')
        print('---->>',self.driver.title)

        pass

    """6)   Execute the launcher file on the target machine  """
    def test_6_Execute_Launcher_on_Target(self):
        self.driver = test_env.driver
        screen_shot = ScreenShot(self.driver)
        self.driver.save_screenshot(str(datetime.datetime.now())+'.png')
        print('---->>',self.driver.title)

        pass

    """7)   Verify that the connection between the grunt and covenant is established """
    def test_7_Verify_is_Grunt_Connection_Establised(self):
        self.driver = test_env.driver
        grunt=Grunt(test_env.driver)
        grunt.verify_grunt_connection_established()







if __name__ == '__main__':
    unittest.main()

