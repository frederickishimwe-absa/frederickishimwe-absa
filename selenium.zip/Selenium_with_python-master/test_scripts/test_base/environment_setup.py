__author__ = 'Frederick'

import os
import datetime
import unittest
from selenium import webdriver
from selenium.webdriver.chrome.options import  Options
from selenium.webdriver.chrome.service import Service

class Environment_Setup():
    def __init__(self):
        self.driver= None
        self.started_time=None
        print('initialise driver')
    
    def setup(self):        
        path_ = os.getcwd() + '/../webdriver/chromedriver'
        options = Options()
        # options.set_capability('acceptInsecureCerts', 'true')
        options.add_argument('ignore-certificate-errors')
        service=Service(executable_path= path_)
        self.driver = webdriver.Chrome(options=options,service=service)
        self.started_time = datetime.datetime.now()
        print('Run Started  : ' + str(self.started_time))
        print('Chrome Environment Setup\n----------------------------')
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()


    def tearDown(self):
        if not (self.driver is None):
            print('\n-----------------------------------------------')
            print('\nDestroying Environment  . . . . . .')
            print('End time : '+str(datetime.datetime.now())+'\t Duration :' +
                  str(datetime.datetime.now()-self.started_time))
            self.driver.close()
            self.driver.quit()
        self.driver =None

